
<?php 

if(isset($_POST['sub']))
{

    $a= $_POST['num1'];
    $b= $_POST['num2'];
    $c= $_POST['num3'];
  
    if ($a == $b && $b==$c|| $b == $a && $c==$a)  {
        echo "triangle valid";
    }     
    else {
        echo "triangle Not valid";
    }
    
}

?>

<form method="post" action="">
all values are equal triangle: 
<input type="number" name="num1">
<input type="number" name="num2">
<input type="number" name="num3">
<button type="submit" name="sub" >Submit</button>
</form>

    