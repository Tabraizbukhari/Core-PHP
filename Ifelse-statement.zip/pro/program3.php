<?php 

if(isset($_POST['sub']))
{
    $a= $_POST['num1'];

if(($a>0)){
    echo "positive";
}
elseif($a<0){
    echo "negative";
}
elseif($a==0)
{
    echo "enter zero";
}
}
?>

<form method="post" action="">
<input type="number" name="num1">
<button type="submit" name="sub" >Submit</button>
</form>

