
<?php 

if(isset($_POST['sub']))
{

    $a= $_POST['num1'];
    $b= $_POST['num2'];
    $c= $_POST['num3'];
    $tot= $a + $b + $c;
   if ($a==$b && $b==$c) {
     echo"there is a triangle";
   }
   elseif($a==$c && $b<$a && $b<$c ){
    echo "isoscaler";

   }
   elseif($a<>$b && $a<>$c && $a<>$b)
   {
    echo"Scalen";
   }
   else{
       echo"the angle is no considered";
   }
}

?>

<form method="post" action="">
180 Enter the there degree value of triangle: 
a=c = isocaler;"
A:<input type="number" name="num1"> <br/>
B:<input type="number" name="num2"><br/>
C;<input type="number" name="num3"><br/>
<button type="submit" name="sub" >Submit</button>
</form>

    