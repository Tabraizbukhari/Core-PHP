<?php 

if(isset($_POST['sub']))
{
    $a= $_POST['num1'];
   

if ($a<=10000) {

    $hra = 20*$a /100;
    $Da =  80*$a/100;

    $Gr = $a +$hra +$Da;

    echo "<h3>your basic salary =". $a . " <br/>";
    echo "HRA are:  ". $hra . "_<br/>";
    echo "DA are:  ". $Da . "_<br/>";

    echo "Gross Slary are  ". $Gr . "_<br/>";
} 



elseif ($a<=20000) {

    $hra = 25*$a /100;
    $Da =  90*$a/100;

    $Gr = $a +$hra +$Da;

    echo "<h3>your basic salary =". $a . " <br/>";
    echo "HRA are:  ". $hra . "_<br/>";
    echo "DA are:  ". $Da . "_<br/>";

    echo "Gross Slary are  ". $Gr . "_<br/>";
} 



elseif ($a>20000) {

    $hra = 30*$a/100;
    $Da =  95*$a/100;

    $Gr = $a +$hra +$Da;

    echo "<h3>your basic salary =". $a . " <br/>";
    echo "HRA are:  ". $hra . "_<br/>";
    echo "DA are:  ". $Da . "_<br/>";

    echo "Gross Slary are  ". $Gr . "_<br/>";
} 

}
?>


<form method="post" action="">
Employe Salary basic
<input type="number" name="num1"><br/>


<button type="submit" name="sub" >Submit</button>
</form>



    
