<?php 

if(isset($_POST['sub']))
{
    $a= $_POST['num1'];

if(($a==365)){
    echo "leap year";
}
elseif($a!=365){
    echo "No leap year";
}
else
{
    echo "error";
}
}
?>

<form method="post" action="">
<input type="number" name="num1">
<button type="submit" name="sub" >Submit</button>
</form>
