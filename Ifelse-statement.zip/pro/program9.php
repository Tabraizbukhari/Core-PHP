<?php
if(isset($_POST['sub']))
{   settype($a, "int");
    settype($b, "int");
    $a= $_POST['num1'];
    $b= 20;
    settype($c, "int");
    $c=  $a / $b;
     echo"total number of notes". $c;
}

?>

<form method="post" action="">
per Note price 16;
enter the amount
<input type="text" name="num1">
<button type="submit" name="sub" >Submit</button>
</form>
