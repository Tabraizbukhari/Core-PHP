
<?php 

if(isset($_POST['sub']))
{
    $a= $_POST['num1'];

if(($a % 2)==0){
    echo "number is even";
}
else
{
    echo "number is odd";
}
}
?>

<form method="post" action="">
<input type="number" name="num1">
<button type="submit" name="sub" >Submit</button>
</form>

    