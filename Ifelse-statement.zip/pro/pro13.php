<?php 

if(isset($_POST['sub']))
{
    $a= $_POST['num1'];
    $b= $_POST['num2'];
    $c= $_POST['num3'];
    $d= $_POST['num4'];

    $result = $a +$b +$c +$d;

    $per = $result*100/400;

if ($result<=400) {
    echo "<h3> obtainded: ". $result . "</h3> <br/>";
}
else{
    echo " <h3>incorrect calculate </h3>";
}

if ($result<=400) {
    echo "<h3> percentage: ". $per . "</h3> <br/>";
}
else{
    echo" <h3> percent out of range </h3>";
}

if ($per>100) {
    echo "<h3>error<h3>";
}
else{
switch($per){
    case ($per>=80):
        echo "<h3> Grade A+ </h3> <br/>";
        break;
        case ($per>=70):
            echo "<h3> Grade A </h3> <br/>";
            break;
            case ($per>=60):
                echo "<h3> Grade B </h3> <br/>";
            break;
            case ($per>=50):
                echo "<h3> Grade C </h3> <br/>";
                break;
                case ($per>=40):
                    echo "<h3> Grade E</h3> <br/>";
                    break;
                    case ($per<40):
                        echo "<h3>  Fail </h3> <br/>";
                        break;
        default;
                    }   
}
}
?>


<form method="post" action="">
Sub1:
<input type="number" name="num1"><br/>
Sub2:
<input type="number" name="num2"><br/>
Sub3:
<input type="number" name="num3"><br/>
Sub4:
<input type="number" name="num4"><br/>

<button type="submit" name="sub" >Submit</button>
</form>

<h3>Total: 400</h3>

    
