<?php 

if(isset($_POST['sub']))
{
    $a= $_POST['num1'];
    
    if($a<=50){
        echo "Rs. 0.50/unit <br/>";
        $pric = $a*0.50;
        echo "<br/> <h3>" .$pric. "</h3>";
        echo "An additional surcharge of 20% is added to the bill <br/>";
        $addi = $pric/100*20;
        $am=$addi+$pric;
        echo "Total Amount =". $am;
      }
      elseif ($a<=100) {
        echo "Rs. 0.75/unit <br/>";
        $total= $a*0.75;
        echo "<br/> <h3>". $total. "</h3>";
        echo "An additional surcharge of 20% is added to the bill <br/>";
        $addi = $total/100*20;
        $am=$addi+$total;
        echo "Total Amount = $am";      
    }
    elseif ($a<=200) {
        echo "Rs. 1.20/unit <br/>";
        $total= $a*1.20;
        echo "<br/> <h3>" .$total ."</h3>";
        echo "An additional surcharge of 20% is added to the bill <br/>";
        $addi = $total/100*20;
        $am=$addi+$total;
        echo "Total Amount = " .$am;      
    }
    elseif ($a<>250) {
        echo "Rs. 1.75/unit <br/>";
        $total= $a*1.75;
        echo "<br/> <h3>" .$total ."</h3>";
        echo "An additional surcharge of 20% is added to the bill <br/>";
        $addi = $total/100*20;
        $am=$addi+$total;
        echo "Total Amount = " .$am;      
    }
    else{

    }


}
?>


<form method="post" action="">
Unit of bills:
<input type="number" name="num1"><br/>
<button type="submit" name="sub" >Submit</button>
</form>



    
