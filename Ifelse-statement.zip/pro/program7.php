<?php
if(isset($_POST['sub']))
{
    $a= $_POST['num1'];
 
if( ctype_upper($a)){
    echo " UPPERCASE";
}
elseif(ctype_lower($a)){
    echo "Lowercase";
}
else{
    echo "Both cases here";
}
}
?>

<form method="post" action="">
uppercase and Lowercase:
<input type="text" name="num1">
<button type="submit" name="sub" >Submit</button>
</form>
