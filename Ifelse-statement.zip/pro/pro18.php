

  <?php 

if(isset($_POST['sub']))
{
    $a= $_POST['num1'];
    
    if( ($a>='a' && $a<='z') || ($a>='A' && $a<='Z')){
        echo"Alphabet";
  
      }
      else {
          echo "not";
      }


}
?>


<form method="post" action="">
Check alphabet or not
<input type="text" name="num1"><br/>
<button type="submit" name="sub" >Submit</button>
</form>



    
