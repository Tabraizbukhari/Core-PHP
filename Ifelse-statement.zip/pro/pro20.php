
<?php 

if(isset($_POST['sub']))
{

    $a= $_POST['num1'];
    $b= $_POST['num2'];
    $c= $_POST['num3'];
    $ROOT1= -$b+sqrt($b*2-4*$a*$c)/2*$a;
    $ROOT2= -$b-sqrt($b*2-4*$a*$c)/2*$a;
    if($ROOT1>0 && $ROOT2>0 )
    {
        echo"Quadric Equation greater >0";
        
    }  
    elseif ($ROOT1<0 && $ROOT2<0 )
    {
        echo"Quadric Equation greater <0";
        
    }  
    else {
        $ROOT1 = $ROOT2 = -$b/2*$a;
        echo" solution Equal". $ROOT1;;
    }
   
    
}

?>

<form method="post" action="">
Quadric Equations
<input type="number" name="num1">
<input type="number" name="num2">
<input type="number" name="num3">

<button type="submit" name="sub" >Submit</button>
</form>

    