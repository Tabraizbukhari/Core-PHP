


<?php 

if(isset($_POST['sub']))
{

    $a= $_POST['num1'];
    $b= $_POST['num2'];
    

 if($a<=$b)
        {
    $p=$a-$b;
    $per=($p*100)/$a;
      $res= "Profit=".$p;
      $res= "Profitpercent=".$p;
    echo $res;        }
        else
    {
        $l=$b-$a;
        $lp=($l*100)/$b;
    $res= "Loss=".$l;
        $res.= ", Loss % =".$lp."";
        echo $res;        }
       
    
}

?>

<form method="post" action="">
PROFIT AND LOSS;
WHOLESALE PRICE<input type="number" name="num1"> <br/>
CUTOMER PRICE<input type="number" name="num2"><br/>
<button type="submit" name="sub" >Submit</button>
</form>

    