<?php 

if(isset($_POST['sub']))
{
    $a= $_POST['num1'];
    $b= $_POST['num2'];
    $c= $_POST['num3'];
if($a>$b && $a>$c){
    echo $a;
}
elseif($b>$a && $b>$c){
    echo $b;
}
elseif($c>$a && $c>$b){
    echo $c;
}
else{
    echo "there is no maximum number";
}
}
?>

<form method="post" action="">
<input type="number" name="num1">
<input type="number" name="num2">
<input type="number" name="num3">
<button type="submit" name="sub" >Submit</button>
</form>

