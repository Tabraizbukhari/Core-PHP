
<?php 

if(isset($_POST['sub']))
{
    $a= $_POST['num1'];
 
    switch($a){
    case 'a':
        echo "wovel";
        break; 
      case 'e':
        echo "wovel";
       break;
        case 'i':
        echo "wovel";
        break;
        case 'o':
        echo "wovel";
       break;
       case 'u':
       echo "wovel";
            break;
                
            
    default;
    echo "consonant"; 
            
    }
}

?>

<form method="post" action="">
write a alphabet:
<input type="text" name="num1">
<button type="submit" name="sub" >Submit</button>
</form>

    