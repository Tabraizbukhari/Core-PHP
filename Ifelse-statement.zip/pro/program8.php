<?php
if(isset($_POST['sub']))
{
    $a= $_POST['num1'];
    switch($a){
        case '1';
        echo "Mon";
    break;
    case '2';
        echo "Tue";
    break;
    case '3';
        echo "Wed";
    break;
    case '4';
        echo "Thu";
    break;
    case '5';
        echo "Fri  ";
    break;
    case '6';
        echo "Sat";
    break;
    case '7';
        echo "Sun";
    break;
    default;
    echo" no week numbers";

    }
}
?>

<form method="post" action="">
Week number 1 t0 7:
<input type="text" name="num1">
<button type="submit" name="sub" >Submit</button>
</form>
