<?php 
if(isset($_POST['sub']))
{
$a= $_POST['num1'];
$b= $_POST['num2'];


if(($a>$b)){
    echo $a;
}
elseif($b>$a){
    echo $b;
}
else{
    echo "there is no maximum number";
}
}
?>

<form method="post" action="">
<input type="number" name="num1">
<input type="number" name="num2">
<button type="submit" name="sub" >Submit</button>
</form>

