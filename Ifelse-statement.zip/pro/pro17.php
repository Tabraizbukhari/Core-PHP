<?php 

if(isset($_POST['sub']))
{
    $a= $_POST['num1'];
    
    if($a % 5==0 OR $a % 11 ==0){
        echo"Divisble by 5 and 11 <br/>";
  
      }
      else {
          echo "not";
      }


}
?>


<form method="post" action="">
Divivble 5 and 11;
<input type="number" name="num1"><br/>
<button type="submit" name="sub" >Submit</button>
</form>



    
