
<?php 

if(isset($_POST['sub']))
{

    $a= $_POST['num1'];
    $b= $_POST['num2'];
    $c= $_POST['num3'];
    $tot= $a + $b + $c;
    switch($tot){
    case '180':
        echo "This is triangle";
        break; 
    default;
    echo "Not a triangle"; 
            
    }
}

?>

<form method="post" action="">
180 Enter the there degree value of triangle: 
<input type="number" name="num1">
<input type="number" name="num2">
<input type="number" name="num3">
<button type="submit" name="sub" >Submit</button>
</form>

    