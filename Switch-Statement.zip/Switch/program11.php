<?php
 settype($a, "int");
settype($b, "int");
settype($c, "int");
$a= $_POST['num1'];
$note= 20;
switch (isset($_POST['btn'])) {
    
   
    case $c= $a/$note:
       
       echo "total number: ". $c ;
        break;
    
    default:
        # code...
        break;
}

?>

<form method="post">
Customer Rs
<input type="text" name="num1"/>
<button name="btn" >Submit</button>

</form>