<?php
if(isset($_POST['btn'])){
    $a= $_POST['num1'];
    switch ($a) {
        case $a>0:
            echo "Positive";
            break;
            case $a<0:
                echo "Negative";
                break;
            
        default:
        echo "Zero value";
    }

}
?>

<form method="post">
<input type="number" name="num1"/>

<button name="btn" >Submit</button>

</form>