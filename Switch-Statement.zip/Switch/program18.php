<?php
if (isset($_POST['btn'])) {
    $a =$_POST['num1'];
   

    
    switch ($a) {
case 1:
echo  "Jan 30 day";
break;
    case 2:
echo  "Feb 28 day";
break;
case 3:
echo  "March 29 day";
break;
case 4:
echo  "Aprail 31 day";
break;

case 5:
echo  "may 30 day";
break;
case 6:
echo  "Jun 31 day";
break;
case 7:
echo  "July 29 day";
break;
case 8:
echo  "Agust 31 day";
break;
case 9:
echo  "Sep 30 day";
break;
case 10:
echo  "Oct 31 day";
break;
case 11:
    echo  "Nov 29 day";
            break;
            case 12:
                echo  "Dec 30 day";
                        break;

            echo"NO Way";
    }
 
  
}
?>

<form method="post">
input month number and print number of days in that month. <br/>
 <input type="text" name="num1"/>



<button name="btn" >Submit</button>


</form>