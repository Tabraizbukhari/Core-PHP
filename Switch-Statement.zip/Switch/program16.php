<?php
if (isset($_POST['btn'])) {
    $a =$_POST['num1'];
   

    switch ($a) {
        case $a<=50:
            $units =$a+0.50;
            echo "amount = " .$units;
            echo "An additional surcharge of 20% <br/>";
            $totl= $units/100 *20;
            echo " <br/>total amount =" .$totl ;
        
            break;
            case $a<=100:
                $units =$a+0.75;
                echo "amount = " .$units;
                echo "An additional surcharge of 20% <br/>";
                $totl= $units/100 *20;
                $add= $units + $totl;
                echo " <br/> total amount =" .$add ;
            
                break;
            case $a<=200:
                $units =$a+1.20;
                echo "amount = " .$units;
                echo "An additional surcharge of 20% <br/>";
                $totl= $units/100 *20;
                $add= $units + $totl;
                echo "<br/> total amount =" .$add ;
                break;
                case $a<>250:
                    $units =$a+1.50;
                    echo "amount = " .$units;
                    echo "An additional surcharge of 20% <br/>";
                    $totl= $units/100 *20;
                    $add= $units + $totl;
                    echo "<br/>  total amount =" .$add ;
                    break;
            default:
            echo"no angle";
    }
}
?>

<form method="post">
Units <input type="text" name="num1"/>
<button name="btn" >Submit</button>


</form>