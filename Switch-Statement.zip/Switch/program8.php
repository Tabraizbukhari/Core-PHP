<?php
if(isset($_POST['btn'])){
    $a= $_POST['num1'];
    switch ($a) {
        case 'a' :
            echo "Vowel";
            break;
        case 'e':
            echo "Vowel";
            break;
            case 'i':
                echo "Vowel";
                break;
                case 'o':
                    echo "Vowel";
                    break;
                    case 'u':
                        echo "Vowel";
                        break;
            
        default:
        echo "Not";
    }

}
?>

<form method="post">
<input type="text" name="num1"/>
<button name="btn" >Submit</button>

</form>