<?php
if (isset($_POST['btn'])) {
    $a =$_POST['num1'];
   

    switch ($a) {
        case $a<=10000:
            $hra = 20*$a /100;
            $Da =  80*$a/100;
            $gr = $a + $hra + $Da;
        echo "total gross = " .$gr;
        
            break;
            case $a<=20000:
                $hra = 25*$a /100;
                $Da =  90*$a/100;
                $gr = $a + $hra + $Da;
            echo "total gross = ". $gr;
            
                break;
            case $a>20000:
            $hra = 30*$a /100;
            $Da =  95*$a/100;
            $gr = $a + $hra + $Da;
        echo "total gross = ". $gr;
        
                break;
            default:
            echo"no angle";
    }
}
?>

<form method="post">
Basic Salary: <input type="text" name="num1"/>
<button name="btn" >Submit</button>


</form>