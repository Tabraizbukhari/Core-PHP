<?php
if (isset($_POST['btn'])) {
    $a = $_POST['num1'];
    $b = $_POST['num2'];
    $c = $_POST['num3'];
function findRoots($a, $b, $c) 
{ 
    
        
   
	// If a is 0, then equation is 
	// not quadratic, but linear 
	if ($a == 0) 
	{ 
		echo "Invalid"; 
		return; 
	} 

	$d = $b * $b - 4 * $a * $c; 
	$sqrt_val = sqrt( abs($d)); 

	if ($d > 0) 
	{ 
		echo "Roots are real and ". 
					"different \n"; 
		echo (-$b + $sqrt_val) / (2 * $a) , "\n", 
			(-$b - $sqrt_val) / (2 * $a); 
	} 
	else if ($d == 0) 
	{ 
		echo "Roots are real and same \n"; 
		echo -$b / (2 * $a); 
	} 
	
	// d < 0 
	else
	{ 
		echo "Roots are complex \n"; 
		echo -$b / (2 * $a) , " + i" , 
			$sqrt_val, "\n" , -$b / (2 * $a), 
							" - i", $sqrt_val; 
    }
} 



findRoots($a, $b, $c); 

} 


?>


  
<form method="post">
input b<br/>
 <input type="text" name="num1"/><br/>
 input a <br/>
 <input type="text" name="num2"/><br/>
 input c<br/>
 <input type="text" name="num3"/><br/>



<button name="btn" >Submit</button>


</form>