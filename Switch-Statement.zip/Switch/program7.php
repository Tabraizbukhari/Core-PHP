<?php
if(isset($_POST['btn'])){
    $a= $_POST['num1'];
    switch ($a) {
        case $a >= 'a' && $a <='z' || $a >= 'A' && $a <='Z' :
            echo "Alphabet";
            break;
        
            
        default:
        echo "Not";
    }

}
?>

<form method="post">
<input type="text" name="num1"/>
<button name="btn" >Submit</button>

</form>