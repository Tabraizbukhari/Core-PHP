<?php
if(isset($_POST['btn'])){
    $a= $_POST['num1'];
    switch ($a) {
        case 1:
            echo "Monday";
            break;
        case 2:
            echo "Tue";
            break;
            case 3:
                echo "Wed";
                break;         
                case 4:
                    echo "Thus";
                    break; 
                    case 5:
                        echo "Fri";
                        break;
                        case 6:
                            echo "Sat";
                            break;
                            case 7:
                                echo "Sun";
                                break;         
        default:
        echo "Not";
    }

}
?>

<form method="post">
<input type="text" name="num1"/>
<button name="btn" >Submit</button>

</form>