<?php
if(isset($_POST['btn'])){
    $a = $_POST['num1'];
    $b = $_POST['num2'];
    $c = $_POST['num3'];
switch ($a && $b && $c) {
    case $a>$b && $a>$c:
        echo"The maximum number is". $a;
        break;
        case $b>$a && $b>$c:
            echo"The maximum number is ". $b;
        break;
    
    case $c>$a && $c>$b:
       echo"The maximum number is ". $c;
        break;
            
    default:
        echo "error";
    
}
}
?>

<form method="post">
<input type="number" name="num1"/>
<input type="number" name="num2"/>
<input type="number" name="num3"/>
<button name="btn" >Submit</button>

</form>