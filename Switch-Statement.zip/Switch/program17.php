<?php
if (isset($_POST['btn'])) {
    $a =$_POST['num1'];
    $b =$_POST['num2'];
    $c =$_POST['num3'];
   $total = 300;
    $obt= $a+$b+$c;
    $per = $obt/$total*100;

    
    switch ($obt) {
        case $obt>300:
        echo"error";
            break;
            case $obt<=300:
            echo " Total number : 300 </br>";
            echo "OBT number " . $obt . "</br>";
            echo "Percentage are = ". $per . "%  </br>";

            switch ($per) {
                case $per>100 :
                    echo"error";
                case $per>=80 :
                echo"A+";
                    break;
                    case $per>=70:
                    echo "A";
                        break;
                        case $per>=60:
                            echo "B";
                        break;
                        case $per>=50:
                            echo "C";
                                break;
                                case $per>=40:
                                    echo "E";
                                        break;
                                        case $per<40:
                                            echo "Fail";
                                                break;
                
                    default:
                    echo"NO Way";
            }
                break;
        
            default:
            echo"NO Way";
    }
 
  
}
?>

<form method="post">
Sub1 <input type="text" name="num1"/>
Sub2 <input type="text" name="num2"/>
Sub3 <input type="text" name="num3"/>


<button name="btn" >Submit</button>


</form>