<?php
if(isset($_POST['btn']))
{
 $a = $_POST['num1'];
 $b = $_POST['num2'];
switch($a && $b){
case $a>$b; 
   echo "The maximum number is". $a;
    break;
    case $b>$a; 
    echo "The maximum number is". $b;
     break;
 default;
}
}
?>


<form method="post">
<input type="number" name="num1"/>
<input type="number" name="num2"/>
<button name="btn" >Submit</button>

</form>