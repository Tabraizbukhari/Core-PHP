<?php
if (isset($_POST['btn'])) {
    $a =$_POST['num1'];
    $b =$_POST['num2'];

    switch ($a) {
        case $a<=$b:
          $p = $a + $b;
          $prof= $p*100/$a;
        
          $res= "Prof=".$p;
          $res.= ", Prercent % =".$prof."";
          echo $res;
            break;
            case $a>=$b:
                $p = $b - $a;
                $prof= $p*100/$b;
                
                 $res= "Loss=".$p;
                $res.= ", Loss % =".$prof."";
                echo $res;   
                  break;
            default:
            echo"no angle";
    }
}
?>

<form method="post">
whole
<input type="text" name="num1"/>
Buyer:<input type="text" name="num2"/>
<button name="btn" >Submit</button>


</form>