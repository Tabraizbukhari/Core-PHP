<?php
if (isset($_POST['btn'])) {
    $a =$_POST['num1'];
    $b =$_POST['num2'];
    $c =$_POST['num3'];

    switch ($c) {
        case $a==$b && $c == $a:
           echo "this are triangle equilateral ";
            break;
     case $a==$b && $b<>$c && $a<>$c:
                echo "this are triangle Isoscalaen ";
                 break;

         case $a<>$b && $b<>$c:
                    echo "this are triangle scalaen ";
                     break;
        default:
            echo"no angle";
    }
}
?>

<form method="post">
Angle a:
<input type="text" name="num1"/>
Angle b:
<input type="text" name="num2"/>

Angle c:
<input type="text" name="num3"/>

<button name="btn" >Submit</button>


</form>