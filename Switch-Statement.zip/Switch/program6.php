<?php
if(isset($_POST['btn'])){
    $a= $_POST['num1'];
    switch ($a) {
        case $a == 365 :
            echo "leap year";
            break;
            case  $a <> 365:
                echo "Not leap year";
                break;
            
        default:
        echo "Error";
    }

}
?>

<form method="post">
<input type="number" name="num1"/>
<button name="btn" >Submit</button>

</form>