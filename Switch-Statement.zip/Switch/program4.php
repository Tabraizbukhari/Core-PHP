<?php
if(isset($_POST['btn'])){
    $a= $_POST['num1'];
    switch ($a) {
        case $a % 5 == 0 :
            echo "Divisible = 5";
            break;
            case  $a % 11 == 0:
                echo "divisible = 11";
                break;
            
        default:
        echo "Error";
    }

}
?>

<form method="post">
<input type="number" name="num1"/>
<button name="btn" >Submit</button>

</form>