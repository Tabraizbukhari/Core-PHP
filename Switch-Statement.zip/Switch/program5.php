<?php
if(isset($_POST['btn'])){
    $a= $_POST['num1'];
    switch ($a) {
        case $a % 2 == 0 :
            echo "even";
            break;
          
        default:
        echo "Odd";
    }

}
?>

<form method="post">
<input type="number" name="num1"/>
<button name="btn" >Submit</button>

</form>