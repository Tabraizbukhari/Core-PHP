<?php
if(isset($_POST['btn'])){
    $a= $_POST['num1'];
    switch ($a) {
        case $a >='a' && $a<='z':
            echo "Lower case";
            break;
        case $a >='A' && $a<='Z':
            echo "Upercase";
            break;
            
            
        default:
        echo "Not";
    }

}
?>

<form method="post">
<input type="text" name="num1"/>
<button name="btn" >Submit</button>

</form>