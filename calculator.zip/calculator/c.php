<?php
if(isset($_POST['btn']))
{
    $a = $_POST['num1'];
    $b = $_POST['num2'];
    $o = $_POST['op'];

    switch ($o) {
        case '+':
            $c= $a+$b;
            break;
            case '-':
                $c= $a-$b;
                break;
                case '/':
                    $c= $a/$b;
                    break;
                    case '*':
                        $c= $a*$b;
                        break;
                        case '%':
                            $c= $a%$b;
                            break;
                            
        
        default:
           echo 'code error';
    }

}
?>
 
 
 
    <form method="post" action="">
        <input type="text" name='num1'>
        <input type="text" name='op' placeholder="operator">
        <input type="text" name='num2'>
        
        <input type="submit" name="btn">
    </form>


<label><?php if(isset($c)){ echo $c; }?></label>