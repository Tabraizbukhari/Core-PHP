<?php


if (isset($_POST['calculate'])) {
    $current_txt = $_POST['txt'];

    $current_txt .= " = " . eval('return ' . $current_txt . ';');
} else {
    $current_txt = NULL;
    $current_txt .= $current_txt;
}


?>

<div style="padding-left: 200px; margin-top: 100px">
  <form  method="post">
    Enter value:  <input type="text" name="txt" value="<?php
    echo $current_txt;
?>" >
    <div style="padding-left: 105px"><br>
      <input type="submit" name="calculate" value="calculate">

    </div>

  </form>
</div>